﻿using System;

namespace Reports
{
    public abstract class ReportGenerator
    {
        public void Generate()
        {
            CollectData();
            Format();
            Save();
        }
        protected void CollectData() { Console.WriteLine("Сбор данных..."); }
        protected abstract void Format();
        protected virtual void Save() { Console.WriteLine("Сохранение в файл..."); }
    }

    public class PdfReport : ReportGenerator
    {
        protected override void Format() { Console.WriteLine("Форматирование PDF..."); }
    }
}