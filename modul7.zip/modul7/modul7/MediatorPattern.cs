﻿using System;
using System.Collections.Generic;

namespace ChatSystem
{
    public interface IMediator { void Send(string msg, User user); }

    public abstract class User
    {
        protected IMediator med;
        public string Name { get; set; }
        public User(IMediator m, string n) { med = m; Name = n; }
        public abstract void Receive(string msg);
    }

    public class ChatMediator : IMediator
    {
        private List<User> _users = new List<User>();
        public void AddUser(User u) { _users.Add(u); }
        public void Send(string msg, User sender)
        {
            foreach (var u in _users) if (u != sender) u.Receive(msg);
        }
    }

    public class ConcreteUser : User
    {
        public ConcreteUser(IMediator m, string n) : base(m, n) { }
        public override void Receive(string msg) { Console.WriteLine(Name + " получил: " + msg); }
    }
}