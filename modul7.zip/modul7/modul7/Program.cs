﻿using System;
using SmartHome;
using Reports;
using ChatSystem;

class Program
{
    static void Main()
    {
        Console.WriteLine("--- Тест Команды ---");
        var remote = new RemoteControl();
        var light = new Light();
        remote.PressButton(new LightOnCommand(light));
        remote.PressUndo();
        Console.WriteLine("\n--- Тест Отчетов ---");
        new PdfReport().Generate();
        Console.WriteLine("\n--- Тест Чата ---");
        var chat = new ChatMediator();
        var u1 = new ConcreteUser(chat, "Несибели");
        var u2 = new ConcreteUser(chat, "Сабина");
        chat.AddUser(u1); chat.AddUser(u2);
        chat.Send("Привет!", u1);

        Console.ReadLine();
    }
}