﻿using System;
using System.Collections.Generic;

namespace SmartHome
{
    public interface ICommand { void Execute(); void Undo(); }

    public class Light { public void On() => Console.WriteLine("Свет включен"); public void Off() => Console.WriteLine("Свет выключен"); }

    public class LightOnCommand : ICommand
    {
        private Light _light;
        public LightOnCommand(Light l) { _light = l; }
        public void Execute() { _light.On(); }
        public void Undo() { _light.Off(); }
    }

    public class RemoteControl
    {
        private Stack<ICommand> _history = new Stack<ICommand>();
        public void PressButton(ICommand cmd) { cmd.Execute(); _history.Push(cmd); }
        public void PressUndo() { if (_history.Count > 0) _history.Pop().Undo(); }
    }
}